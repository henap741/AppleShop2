package model;
//Template of a collection of entries
public class RefurbishedStore {
	private Entry[] entries; //array of Entry object
	//Two purpose of auxiliary counter:
	//1. Record how many (non-null) entries have been stored in the 'entries' array
	//2. Indicates the index of the entries array that will store the next new entry reference
	private int noe; 
	private final int MAX_CAPACITY = 5; //max capacity
	
	public RefurbishedStore() {
		this.entries = new Entry[MAX_CAPACITY];
		this.noe = 0;
	}
	
	public int getNumberofEntries() {
		return this.noe;
	}
	
	public Entry[] getPrivateEntriesArray() {
		return this.entries;
	}
	
	public Entry[] getEntries() {
		Entry[] es = new Entry[this.noe];
		for(int i = 0; i < this.noe; i ++) {
			es[i] = this.entries[i];
		}
		return es;
	}
		
	public void addEntry(Entry e) {
		this.entries[this.noe] = e;
		this.noe ++;
	}
	
	public void addEntry(String sn, Product p) {
		this.addEntry(new Entry(sn, p));
//		this.entries[this.noe] = ne;
//		this.noe ++;
	}
	
	public void addEntry(String sn, String model, double originalPrice) {
		this.addEntry(new Entry(sn, new Product(model, originalPrice)));
//		Product p = new Product(model, originalPrice);
//		Entry ne = new Entry(sn, p);
//		this.entries[this.noe] = ne;
//		this.noe ++;
	}
	
	public Product getProduct(String sn) {
		int index = -1;
		//Problematic exit condition: i < this.entries.length
		for(int i = 0; i < this.noe; i ++) {
			Entry e = this.entries[i];
			if(e.getSerialNumber().equals(sn)) {
				index = i;
			}
		}
		
		if(index < 0) {
			return null;
		}
		else {
		return this.entries[index].getProduct();
		}
	}
	
	//return serial numbers of space grey finish or pro product
	public String[] getSpaceGreyOrPro() {
		int count = 0;
		int[] indices = new int[this.noe];
		//step 1: collect all product satisfying the search criteria
		for(int i = 0; i < this.noe; i++) {
			Product p = this.entries[i].getProduct();
			if(p.getModel().contains("Pro") || (p.getFinish() != null && p.getFinish().equals("Space Grey"))) {
				indices[count] = i;
				count ++;
			}
		}
		//Step 2: create array of string (for serial numbers) whose size is 'count'
		String[] sns = new String[count];
		for(int i = 0; i < count; i++) {
			sns[i] = this.entries[indices[i]].getSerialNumber();
		}
		
		return sns;
	}
	
	//return serial numbers of both space grey finish and pro product
	public String[] getSpaceGreyPro() {
		int count = 0;
		int[] indices = new int[this.noe];
		//step 1: collect all product satisfying the search criteria
		for(int i = 0; i < this.noe; i++) {
			Product p = this.entries[i].getProduct();
			if(p.getModel().contains("Pro") && p.getFinish() != null && p.getFinish().equals("Space Grey")) {
				indices[count] = i;
				count ++;
			}
		}
		//Step 2: create array of string (for serial numbers) whose size is 'count'
		String[] sns = new String[count];
		for(int i = 0; i < count; i++) {
			sns[i] = this.entries[indices[i]].getSerialNumber();
		}
		
		return sns;
	}
}
